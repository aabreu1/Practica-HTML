$(function()
{	
errorNom.style.visibility = 'hidden';
		errordia.style.visibility = 'hidden';
		errormes.style.visibility = 'hidden';
		errortarjeta.style.visibility = 'hidden';
	});